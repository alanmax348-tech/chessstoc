Place your assets here (exact filenames):
  neoboard.png
  wk.png wq.png wr.png wb.png wn.png wp.png
  bk.png bq.png br.png bb.png bn.png bp.png
